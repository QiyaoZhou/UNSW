DROP FUNCTION convert_string(GeoCoord);
DROP FUNCTION dms_string(text);
DROP TABLE Locations CASCADE;