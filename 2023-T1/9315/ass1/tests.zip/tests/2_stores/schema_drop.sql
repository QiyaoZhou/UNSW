DROP FUNCTION convert_string(GeoCoord);
DROP TABLE StoreInfo CASCADE;