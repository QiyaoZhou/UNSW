-- comp9311 22T1 Project 1
--
-- MyMyUNSW Solutions


-- Q1:
create or replace view Q1(subject_name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q2:
create or replace view Q2(course_id)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q3:
create or replace view Q3(course_id, use_rate)
as 
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q4:
create or replace view Q4(facility)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

--Q5:
create or replace view Q5(unsw_id, student_name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q6:
create or replace view Q6(subject_name, non_null_mark_count, null_mark_count)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q7:
create or replace view Q7(school_name, stream_count)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q8: 
create or replace view Q8(student_name_local, student_name_intl)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q9:
create or replace view Q9(ranking, course_id, subject_name, student_diversity_score)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q10:
create or replace view Q10(subject_code, avg_mark)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q11:
create or replace view Q11(subject_code, inc_rate)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q12:
create or replace view Q12(name, subject_code, year, term, lab_time_per_week)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q13:
create or replace view Q13(subject_code, year, term, fail_rate)
as
--... SQL statements, possibly using other views/functions defined by you ...
;